﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nes.Web.Models;

namespace Nes.Web
{
    public static class AuthConfig
    {
        public static void RegisterAuth()
        {
         
        }
    }
}
